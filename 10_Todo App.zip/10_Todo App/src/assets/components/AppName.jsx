function AppName(){
    return(
        <center className="todo-container">
            <h1>Todo App</h1>
            <div class="row">
            <div class="col-6">
            <input type="text"  placeholder="Enter Here"  />
            </div>
            <div class="col-4">
                <input type="date" />
            </div>
            <div class="col-2">
              <button type="button" class="btn btn-success bg-button">Add</button>
            </div>
        </div>
        </center>
        
    );
 }
 
 export default AppName;