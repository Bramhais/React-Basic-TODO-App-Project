
function component2(){
    return(
        <center className="todo-container">
    
        <div class="row">
        <div class="col-6">
        Go To Home
        </div>
        <div class="col-4">
           23/02/2024
        </div>
        <div class="col-2">
          <button type="button" class="btn btn-danger bg-button">Delete</button>
        </div>
    </div>
    </center>
    );
 }
 
 export default component2;