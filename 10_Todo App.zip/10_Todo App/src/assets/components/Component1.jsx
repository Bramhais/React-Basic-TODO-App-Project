
function component1(){
    return(
        <center className="todo-container">
    
        <div class="row">
        <div class="col-6">
         Buy Milk
        </div>
        <div class="col-4">
           23/02/2024
        </div>
        <div class="col-2">
          <button type="button" class="btn btn-danger">Delete</button>
        </div>
    </div>
    </center>
    );
 }
 
 export default component1;