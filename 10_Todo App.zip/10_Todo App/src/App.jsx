
import 'bootstrap/dist/css/bootstrap.min.css'
import AppName from './assets/components/AppName'
import Component1 from './assets/components/Component1'
import Component2 from './assets/components/Component2'
import './App.css'

function App() {
 return(
  <>
    <AppName></AppName>
    <Component1></Component1>
    <Component2></Component2>

    </>
 );
}

export default App
